// Constants
const { token } = require('./config.json');
const { Client, Events, GatewayIntentBits, SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
const csv = require('csv-parser');

let scpData = [];

// Parse the CSV file and load it into scpData
fs.createReadStream('./SCP_entities.csv')
    .pipe(csv({ headers: ['id', 'images', 'name', 'object_class', 'special_containment_procedures', 'description'] }))
    .on('data', (row) => {
        scpData.push(row);
    })
    .on('end', () => {
        console.log('CSV file successfully processed. Total entries:', scpData.length);
        console.log('SCP Data:', scpData.slice(0, 5));
    });

// Base delay values
minDelay = 60000; // 1 minute in milliseconds
maxDelay = 1800000; // 30 minutes in milliseconds

// Sets the mode to either test or run
const testOrRun = "long test"; // "test" or "run"

if (testOrRun === "test") {
    console.log("Test mode enabled. 30 seconds to 5 minutes delay between messages.");
    minDelay = 30000; // 30 seconds in milliseconds
    maxDelay = 300000; // 5 minutes in milliseconds
}
else if (testOrRun === "run") {
    console.log("Run mode enabled. 1 to 24 hours delay between messages.");
    minDelay = 3600000; // 1 hour in milliseconds
    maxDelay = 86400000; // 24 hours in milliseconds
}
else if (testOrRun === "long test") {
    console.log("Long test mode enabld. 10 minutes to 1 hour delay between messages.");
    minDelay = 600000; // 10 minutes in milliseconds
    maxDelay = 3600000; // 1 hour in milliseconds
}
else {
    console.error("Invalid mode selected. Please choose either 'test', 'run' or 'long test'.");
    process.exit(1);
}

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMembers,
    ]
});

const messages = [
    "Containment breach detected.",
    "Entity sighted in channel #X.",
    "Unauthorized access to █████ detected.",
    "WARNING: Level 5 clearance required to view █████.",
    "Containment breach detected in ██████. Immediate response required.",
    "Entity #███ has been sighted in channel #X.",
    "WARNING: Anomalous activity detected in server logs.",
    "Do not trust what you see in █████.",
    "Unauthorized access attempt to classified channel detected.",
    "Caution: Temporal anomalies are affecting user roles.",
    "The countdown has started. ████ days remain.",
    "Entity SCP-███ has escaped from containment. Proceed with caution.",
    "Channel #X is no longer safe. Evacuate immediately.",
    "Security clearance Level 4 required to proceed.",
    "The █████ is watching. Do not respond.",
    "Containment protocols for SCP-███ have failed.",
    "Class D Personnel have been reassigned. Report immediately.",
    "Unknown signal detected in #X. Analysis required.",
    "Reality distortion event detected in channel #X.",
    "Mobile Task Force Unit ████ has been deployed.",
    "Do not approach the ██████ under any circumstances.",
    "Containment breach simulation in progress. This is not a drill.",
    "Report anomalies in ████ to the nearest administrator.",
    "SCP-███ has breached Level 3 security. Lockdown initiated.",
    "O5 Council authorization required to access ██████.",
    "WARNING: Memetic hazard detected in channel #X.",
    "Classified documents have been uploaded to #X.",
    "All personnel are advised to remain calm during the ██████ event.",
    "Unexplained personnel shifts detected. Investigate immediately.",
    "Audio logs in ████ reveal unknown voices.",
    "Level 5 security protocols have been breached.",
    "The ██th iteration is complete. Await further instructions.",
    "Temporal displacement detected in user roles.",
    "Biohazard alert in channel #X. Quarantine in effect.",
    "Unauthorized user ██████ has entered containment zone.",
    "Caution: Anomaly ████ exhibits predatory behavior.",
    "Incident report ████ has been uploaded to the archives.",
    "Prepare for immediate site lockdown.",
    "The ██████ event begins at ████.",
    "Reality destabilization detected in server logs.",
    "Site Overseer ████ has issued a containment order.",
    "SCP-███ terminated. Recontainment not possible.",
    "The ██████ protocol has been activated.",
    "All personnel are required to undergo memetic resistance training.",
    "Entity ████ has infiltrated server roles.",
    "Anomalous data detected in user activity logs.",
    "Containment breach imminent. Standby for instructions.",
    "The SCP Foundation thanks you for your cooperation.",
    "Incident Response Team ████ has neutralized the threat.",
    "Reality stabilization protocols have failed. Proceed with caution.",
    "Containment field for SCP-███ is fluctuating.",
    "Classified operation ████ is now in effect.",
    "Channel #X will be permanently archived.",
    "The O5 Council is monitoring server activity."
];

const roles = [
    { name: "Class D Personnel", color: 0xFFA500 },                             // Orange
    { name: "Containment Specialist", color: 0x006400 },                        // Dark Green
    { name: "Level 1 Security", color: 0x0000FF },                              // Blue
    { name: "Site Overseer", color: 0x800080 },                                 // Purple
    { name: "Entity Containment Unit", color: 0x8B0000 },                       // Dark Red
    { name: "Foundation Researcher", color: 0xFFFF00 },                         // Yellow
    { name: "Head of Security", color: 0x00008B },                              // Dark Blue
    { name: "Site Administrator", color: 0xFFD700 },                            // Gold
    { name: "Incident Response Team", color: 0xFF0000 },                        // Red
    { name: "Junior Researcher", color: 0xD3D3D3 },                             // Light Grey
    { name: "Level 2 Security", color: 0x000080 },                              // Navy
    { name: "Containment Breach Response", color: 0xFF4500 },                   // Dark Orange
    { name: "Experimental Unit", color: 0x00FFFF },                             // Aqua
    { name: "Mobile Task Force", color: 0x228B22 },                             // Forest Green
    { name: "Biohazard Unit", color: 0x9370DB },                                // Medium Purple
    { name: "Anomalous Analyst", color: 0x008080 },                             // Teal
    { name: "Ethics Committee Member", color: 0xFF69B4 },                       // Hot Pink
    { name: "Site Intelligence Officer", color: 0x808080 },                     // Grey
    { name: "Facility Maintenance", color: 0xDAA520 },                          // Goldenrod
    { name: "Containment Architect", color: 0xA52A2A },                         // Brown
    { name: "Temporal Investigator", color: 0x696969 },                         // Dim Grey
    { name: "SCP Archivist", color: 0x32CD32 },                                 // Lime Green
    { name: "Reality Stabilizer", color: 0x90EE90 },                            // Light Green
    { name: "Level 3 Security", color: 0x008080 },                              // Dark Teal
    { name: "O5 Council", color: 0xFFFFFF },                                    // White
    { name: "Chief of Procrastination", color: 0xFFD700 },                      // Gold
    { name: "Master of Disguises", color: 0x800080 },                           // Purple
    { name: "Professional Napper", color: 0xD3D3D3 },                           // Light Grey
    { name: "Lord of Memes", color: 0x00FF00 },                                 // Lime Green
    { name: "Banana Enthusiast", color: 0xFFFF00 },                             // Yellow
    { name: "Human Error", color: 0xFF6347 },                                   // Tomato Red
    { name: "Certified Couch Potato", color: 0xA52A2A },                        // Brown
    { name: "Wannabe Wizard", color: 0x8A2BE2 },                                // Blue Violet
    { name: "Unpaid Intern", color: 0x808080 },                                 // Grey
    { name: "Future Millionaire", color: 0xFFD700 },                            // Gold
    { name: "Level 0 Security (Just Here for the Snacks)", color: 0xF0E68C }    // Khaki
];

const unsettlingPhrases = [
    "We see you, @USER.",
    "Are you sure you're alone, @USER?",
    "They’re watching, @USER.",
    "Look behind you, @USER.",
    "You can’t escape, @USER.",
    "@USER, something’s not right here.",
    "They’ve been looking for you, @USER.",
    "You heard that, didn’t you, @USER?",
    "It’s too late now, @USER.",
    "They know, @USER. They always know."
];

// Functions for multiple things
function getDelay() {
    const delay = getRandomTime(minDelay, maxDelay);

        // Calculate hours, minutes, seconds, and milliseconds
        const hours = Math.floor(delay / 3600000); // 1 hour = 3600000 ms
        const minutes = Math.floor((delay % 3600000) / 60000); // 1 minute = 60000 ms
        const seconds = Math.floor((delay % 60000) / 1000); // 1 second = 1000 ms
        const milliseconds = delay % 1000; // Remaining milliseconds

        // Format the time in hours:min:sec:mil format
        console.log(`Next message rotation in ${hours}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}:${String(milliseconds).padStart(3, '0')} (h:mm:ss:ms)`);
    
    return delay;
}

function getRandomChannel(guild) {
    const channels = guild.channels.cache.filter(
        (channel) => channel.isTextBased() && channel.permissionsFor(guild.members.me).has('SendMessages')
    );
    return channels.random();
}

function getRandomTime(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

async function sendRandomMessage(guild) {
    while (true) {
        const delay = getDelay();

        await new Promise((resolve) => setTimeout(resolve, delay));

        const channel = getRandomChannel(guild);
        if (channel) {
            const message = messages[Math.floor(Math.random() * messages.length)]
                .replace("#X", `#${channel.name}`);
            console.log(`Sending message to ${channel.name} in ${guild.name}`);
            console.log(message);
            await channel.send(message);
        }
    }
}

async function ensureRoles(guild) {
    const existingRoles = guild.roles.cache;
    for (const roleData of roles) {
        if (!existingRoles.some((role) => role.name === roleData.name)) {
            await guild.roles.create({
                name: roleData.name,
                color: roleData.color, // Using numeric color
                reason: "For mysterious role assignments"
            });
        }
    }
}

async function assignRandomRole(guild) {
    console.log(`Starting role assignment in guild: ${guild.name}`);

    // Fetch all members to ensure they're cached
    await guild.members.fetch();
    const members = guild.members.cache.filter((member) => !member.user.bot);
    
    console.log(`Eligible members count: ${members.size}`);

    // Log all roles in the guild to check for issues
    console.log("Guild Roles:", guild.roles.cache.map((role) => role.name));

    const randomMember = members.random();

    if (randomMember) {
        console.log(`Selected member: ${randomMember.user.tag} (${randomMember.id})`);

        // Remove all bot-created roles
        const botRoles = roles.map((r) => r.name);
        const rolesToRemove = randomMember.roles.cache.filter((role) => botRoles.includes(role.name));
        for (const role of rolesToRemove.values()) {
            try {
                await randomMember.roles.remove(role);
                console.log(`Removed role "${role.name}" from ${randomMember.user.tag}`);
            } catch (error) {
                console.error(`Failed to remove role "${role.name}" from ${randomMember.user.tag}:`, error);
            }
        }

        // Select a random role from your roles array
        const randomRoleData = roles[Math.floor(Math.random() * roles.length)];
        console.log(`Attempting to find role: ${randomRoleData.name}`);

        // Check if the role is available in the guild roles cache
        const randomRole = guild.roles.cache.find((role) => role.name === randomRoleData.name);
        if (randomRole) {
            console.log(`Found role: ${randomRole.name}`);

            // Assign the role
            try {
                await randomMember.roles.add(randomRole);
                console.log(`Assigned role "${randomRole.name}" to ${randomMember.user.tag}`);
            } catch (error) {
                console.error(`Failed to assign role "${randomRole.name}" to ${randomMember.user.tag}:`, error);
            }
        } else {
            console.log(`No match for role: ${randomRoleData.name}`);
            console.warn(`No valid roles found to assign in guild: ${guild.name}`);
        }
    } else {
        console.warn(`No eligible members found for role assignment in guild: ${guild.name}`);
    }
}

async function rotateRoles(guild) {
    console.log(`Starting role rotation for guild: ${guild.name}`);

    while (true) {
        const delay = getDelay();

        await new Promise((resolve) => setTimeout(resolve, delay));

        console.log(`Rotating roles in guild: ${guild.name}`);
        try {
            await assignRandomRole(guild);
        } catch (error) {
            console.error(`Error during role rotation in guild: ${guild.name}`, error);
        }
    }
}

async function hauntUser(guild) {
    console.log(`Starting user haunting in guild: ${guild.name}`);

    while (true) {
        const delay = getDelay();

        await new Promise((resolve) => setTimeout(resolve, delay));

        // Fetch all eligible users (exclude bots)
        await guild.members.fetch(); // Ensure members are cached
        const members = guild.members.cache.filter((member) => !member.user.bot);
        const randomMember = members.random();

        if (!randomMember) {
            console.warn(`No eligible users to haunt in guild: ${guild.name}`);
            continue;
        }

        // Get a random channel to send the message
        const channel = getRandomChannel(guild);
        if (!channel) {
            console.warn(`No valid channels to haunt in guild: ${guild.name}`);
            continue;
        }

        // Get a random unsettling phrase and replace @USER with the tagged user's mention
        const phrase = unsettlingPhrases[Math.floor(Math.random() * unsettlingPhrases.length)];
        const hauntingMessage = phrase.replace("@USER", randomMember.toString());

        console.log(`Haunting ${randomMember.user.tag} in channel #${channel.name}`);
        await channel.send(hauntingMessage);
    }
}

function garbleText(text) {
    const glitchCharacters = { a: '@', e: '3', i: '1', o: '0', u: 'ü', s: '$', l: '|', t: '+' };
    return text
        .split('')
        .map((char) => (Math.random() < 0.3 && glitchCharacters[char.toLowerCase()] ? glitchCharacters[char.toLowerCase()] : char))
        .join('');
}

async function garbleRandomUserOrMessage(guild) {
    console.log(`Starting username/message garbling in guild: ${guild.name}`);

    while (true) {
        const delay = getDelay(); // Use the existing getDelay function for consistent timing
        await new Promise((resolve) => setTimeout(resolve, delay));

        // Fetch all eligible users (exclude bots)
        await guild.members.fetch();
        const members = guild.members.cache.filter((member) => !member.user.bot);
        const randomMember = members.random();

        if (!randomMember) {
            console.warn(`No eligible users to garble in guild: ${guild.name}`);
            continue;
        }

        // Select a random channel
        const channel = getRandomChannel(guild);
        if (!channel) {
            console.warn(`No valid channels to garble messages in guild: ${guild.name}`);
            continue;
        }

        // Decide whether to garble a username or send a distorted message
        if (Math.random() < 0.5) {
            // Garble username
            const garbledUsername = garbleText(randomMember.user.username);
            console.log(`Garbling username: ${randomMember.user.username} -> ${garbledUsername}`);
            await channel.send(`Did someone say "${garbledUsername}"?`);
        } else {
            // Garble a random unsettling phrase
            const randomMessage = unsettlingPhrases[Math.floor(Math.random() * unsettlingPhrases.length)];
            const garbledMessage = garbleText(randomMessage.replace("@USER", randomMember.toString()));
            console.log(`Garbling message: "${randomMessage}" -> "${garbledMessage}"`);
            await channel.send(garbledMessage);
        }
    }
}

async function pingAndDelete(guild) {
    console.log(`Starting Ping-and-Delete in guild: ${guild.name}`);

    while (true) {
        const delay = getDelay(); // Use the existing getDelay function for consistent timing
        console.log(`Next Ping-and-Delete in ${delay / 1000} seconds`);
        await new Promise((resolve) => setTimeout(resolve, delay));

        // Fetch all eligible users (exclude bots)
        await guild.members.fetch();
        const members = guild.members.cache.filter((member) => !member.user.bot);
        const randomMember = members.random();

        if (!randomMember) {
            console.warn(`No eligible users to ping in guild: ${guild.name}`);
            continue;
        }

        // Select a random channel
        const channel = getRandomChannel(guild);
        if (!channel) {
            console.warn(`No valid channels to ping in guild: ${guild.name}`);
            continue;
        }

        try {
            // Send the ping message
            const message = await channel.send(`Hey ${randomMember.toString()}, are you there?`);
            console.log(`Pinged ${randomMember.user.tag} in channel #${channel.name}`);

            // Wait for a short period (e.g., 5-10 seconds) before deleting the message
            const deleteDelay = Math.random() * (10000 - 5000) + 5000; // 5-10 seconds
            await new Promise((resolve) => setTimeout(resolve, deleteDelay));

            // Delete the message
            await message.delete();
            console.log(`Deleted message pinging ${randomMember.user.tag} in channel #${channel.name}`);
        } catch (error) {
            console.error(`Failed to ping or delete message in guild: ${guild.name}`, error);
        }
    }
}

function createHiddenText(message) {
    // Randomly apply different obfuscation styles
    const styles = [
        // Use spoiler tags
        () => `||${message}||`,
        // Insert zero-width spaces between characters
        () => message.split('').join('\u200B'),
        // Combine spoiler tags and zero-width spaces
        () => `||${message.split('').join('\u200B')}||`,
    ];

    // Pick a random style
    return styles[Math.floor(Math.random() * styles.length)]();
}

async function sendHiddenTextMessages(guild) {
    console.log(`Starting Hidden Text Messages in guild: ${guild.name}`);

    while (true) {
        const delay = getDelay(); // Use the existing getDelay function for consistent timing
        console.log(`Next hidden text message in ${delay / 1000} seconds`);
        await new Promise((resolve) => setTimeout(resolve, delay));

        // Select a random channel
        const channel = getRandomChannel(guild);
        if (!channel) {
            console.warn(`No valid channels to send hidden messages in guild: ${guild.name}`);
            continue;
        }

        // Get a random message from the existing messages array
        const message = messages[Math.floor(Math.random() * messages.length)];

        // Apply the hidden text formatting
        const hiddenMessage = createHiddenText(message);

        console.log(`Sending hidden text message to channel #${channel.name}: "${hiddenMessage}"`);
        try {
            await channel.send(hiddenMessage);
        } catch (error) {
            console.error(`Failed to send hidden message in guild: ${guild.name}`, error);
        }
    }
}

// Event listeners
client.once(Events.ClientReady, async (c) => {
    console.log(`Logged in as ${c.user.tag}`);

    // Registering the 'ping' command globally
    const ping = new SlashCommandBuilder()
        .setName('ping')
        .setDescription('Replies with Pong!');
    
    try {
        await client.application.commands.create(ping, "1300515057309978645");
        console.log("Ping command registered successfully.");
    } catch (err) {
        console.error("Error registering ping command:", err);
    }

    // Send random messages to all guilds
    for (const guild of client.guilds.cache.values()) {
        sendRandomMessage(guild).catch(console.error);
    }

    // Ensure roles and rotate roles asynchronously
    for (const guild of client.guilds.cache.values()) {
        await ensureRoles(guild);
        rotateRoles(guild).catch(console.error);
    }

    // Ensure haunting starts for each guild
    for (const guild of client.guilds.cache.values()) {
        hauntUser(guild).catch(console.error);
    }

    // Start garbling usernames/messages in all guilds
    for (const guild of client.guilds.cache.values()) {
        garbleRandomUserOrMessage(guild).catch(console.error);
    }

    // Start Ping-and-Delete for each guild
    for (const guild of client.guilds.cache.values()) {
        pingAndDelete(guild).catch(console.error);
    }

    // Start sending hidden messages for each guild
    for (const guild of client.guilds.cache.values()) {
        sendHiddenTextMessages(guild).catch(console.error);
    }

    const scpCommand = new SlashCommandBuilder()
    .setName('scp')
    .setDescription('Retrieve information about an SCP.')
    .addStringOption(option =>
        option.setName('id_or_name')
            .setDescription('Enter the SCP ID (e.g., SCP-001) or name')
            .setRequired(true)
    );
    await client.application.commands.create(scpCommand.toJSON());
    console.log('SCP command registered!');

    const countdownCommand = new SlashCommandBuilder()
    .setName('countdown')
    .setDescription('Initiate a countdown.')
    .addIntegerOption(option =>
        option.setName('hours')
            .setDescription('Hours for the countdown')
            .setRequired(false)
    )
    .addIntegerOption(option =>
        option.setName('minutes')
            .setDescription('Minutes for the countdown')
            .setRequired(false)
    )
    .addIntegerOption(option =>
        option.setName('seconds')
            .setDescription('Seconds for the countdown')
            .setRequired(false)
    );
    await client.application.commands.create(countdownCommand.toJSON());
    console.log('Countdown command registered!');


});

// Handle interactions
client.on(Events.InteractionCreate, async (interaction) => {
    if (!interaction.isChatInputCommand()) return;

    if (interaction.commandName === 'ping') {
        await interaction.reply('Pong!');
    }

    if (interaction.commandName === 'scp') {
        // Check if SCP data is loaded
        if (scpData.length === 0) {
            await interaction.reply('SCP data is still loading. Please try again in a moment.');
            return;
        }
    
        const query = interaction.options.getString('id_or_name')?.toLowerCase();
    
        if (!query) {
            await interaction.reply('Please provide a valid SCP ID or name.');
            return;
        }
    
        const result = scpData.find(scp =>
            (scp.id?.toLowerCase() === query) || (scp.name?.toLowerCase().includes(query))
        );
    
        console.log('Query:', query); // Debug query
        console.log('Result:', result); // Debug result object
    
        if (result) {
            // Truncate function to ensure fields don't exceed Discord's limits
            const truncate = (text, maxLength) =>
                text.length > maxLength ? text.slice(0, maxLength - 3) + '...' : text;
    
            // Validate the image URL
            const isValidUrl = (url) => {
                try {
                    new URL(url); // Validate URL
                    return true;
                } catch (e) {
                    return false;
                }
            };
    
            const embed = {
                color: 0x0099ff,
                title: result.name || 'Classified Information',
                description: `**ID**: ${result.id || 'Classified'}\n**Object Class**: ${result.object_class || 'Classified'}\n\n**Special Containment Procedures**:\n${truncate(result.special_containment_procedures || 'Classified', 1024)}\n\n**Description**:\n${truncate(result.description || 'Classified', 2048)}`,
                footer: { text: 'SCP Foundation Database' },
            };
    
            // Add the image only if the URL is valid
            if (isValidUrl(result.images)) {
                embed.image = { url: result.images };
            }
    
            await interaction.reply({ embeds: [embed] });
        } else {
            await interaction.reply(`No SCP found matching "${query}". Please try again.`);
        }
    }

    if (interaction.commandName === 'countdown') {
        const hours = interaction.options.getInteger('hours') || 0;
        const minutes = interaction.options.getInteger('minutes') || 0;
        const seconds = interaction.options.getInteger('seconds') || 0;

        const totalMilliseconds = (hours * 3600 + minutes * 60 + seconds) * 1000;

        if (totalMilliseconds <= 0) {
            await interaction.reply('Please provide a valid countdown duration.');
            return;
        }

        let remainingMilliseconds = totalMilliseconds;

        // Send an initial message to confirm the countdown
        const message = await interaction.reply({
            content: `Countdown started: ${hours}h ${minutes}m ${seconds}s.`,
            fetchReply: true,
        });

        // Update the countdown periodically
        const interval = setInterval(() => {
            if (remainingMilliseconds <= 0) {
                clearInterval(interval);
                message.edit('Countdown complete! 🎉');
                return;
            }

            remainingMilliseconds -= 1000;

            // Calculate remaining time
            const remainingHours = Math.floor(remainingMilliseconds / 3600000);
            const remainingMinutes = Math.floor((remainingMilliseconds % 3600000) / 60000);
            const remainingSeconds = Math.floor((remainingMilliseconds % 60000) / 1000);

            // Update the message with the remaining time
            message.edit(`Time remaining: ${remainingHours}h ${remainingMinutes}m ${remainingSeconds}s.`);
        }, 1000);
    }
});

client.login(token);